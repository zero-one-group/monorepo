import type { Config } from '@react-router/dev/config'

export default {
  ssr: false /* To enable SSR, set this to `true` */,
} satisfies Config
