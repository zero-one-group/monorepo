// @ref: https://dev.to/codeparrot/test-your-react-apps-with-vitest-2llb
// @ref: https://www.machinet.net/tutorial-eng/vitest-coverage-comprehensive-guide

import "@testing-library/jest-dom/vitest";
