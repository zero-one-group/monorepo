import type { Config } from '@react-router/dev/config'

export default {
  ssr: true /* To disable SSR, set this to `false` */,
} satisfies Config
