// @ref: https://dev.to/codeparrot/test-your-react-apps-with-vitest-2llb
// @ref: https://www.machinet.net/tutorial-eng/vitest-coverage-comprehensive-guide
// @ref: https://nextjs.org/docs/app/building-your-application/testing/vitest

import "@testing-library/jest-dom/vitest";
