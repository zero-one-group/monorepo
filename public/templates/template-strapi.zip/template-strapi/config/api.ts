export default {
  rest: {
    defaultLimit: 25,
    maxLimit: 99999,
    withCount: true,
  },
}
